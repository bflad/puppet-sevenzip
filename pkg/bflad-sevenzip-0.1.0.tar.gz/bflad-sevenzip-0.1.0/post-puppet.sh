if [ -f "/etc/redhat-release" ]; then
  service iptables stop
fi
